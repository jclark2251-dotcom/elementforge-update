<?php
namespace ElementForge\Includes;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Class Plugin_Updater
 *
 * Handles self-hosted WordPress plugin updates.
 */
class Plugin_Updater {

    /**
     * The plugin main file path.
     *
     * @var string
     */
    private $plugin_file;

    /**
     * The update URL hosting the version JSON.
     *
     * @var string
     */
    private $update_url;

    /**
     * The plugin slug (directory name).
     *
     * @var string
     */
    private $slug;

    /**
     * The plugin basename (e.g. elementforge/elementforge.php).
     *
     * @var string
     */
    private $plugin_basename;

    /**
     * Transient cache key for update info.
     *
     * @var string
     */
    private $cache_key = 'elementforge_remote_update_info';

    /**
     * Constructor.
     *
     * @param string $plugin_file Path to the main plugin file.
     * @param string $update_url  URL to check for updates.
     */
    public function __construct( $plugin_file, $update_url ) {
        $this->plugin_file     = $plugin_file;
        $this->update_url      = $update_url;
        $this->plugin_basename = plugin_basename( $plugin_file );
        $this->slug            = dirname( $this->plugin_basename );

        $this->init_hooks();
    }

    /**
     * Initialize updater filters and actions.
     */
    private function init_hooks() {
        // Intercept update checks
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_update' ] );

        // Provide plugin info popups
        add_filter( 'plugins_api', [ $this, 'plugin_popup_info' ], 20, 3 );

        // Flush updater cache when WordPress deletes the updates transient (e.g., clicking "Check Again")
        add_action( 'delete_site_transient_update_plugins', [ $this, 'delete_transient_cache' ] );

        // Flush cache on plugin activation so the first check is always fresh
        register_activation_hook( $this->plugin_file, [ $this, 'delete_transient_cache' ] );
    }

    /**
     * Fetch remote version info from the JSON endpoint.
     *
     * @return object|false Remote metadata object on success, false on failure.
     */
    private function get_remote_info() {
        // Try transient cache first
        $cached = get_transient( $this->cache_key );
        if ( false !== $cached ) {
            return $cached;
        }

        // Fetch updates from the custom endpoint
        $response = wp_remote_get(
            $this->update_url,
            [
                'timeout'    => 15,
                'sslverify'  => false,
                'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 (ElementForge Updater)',
                'headers'    => [
                    'Accept' => 'application/json',
                ],
            ]
        );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            // Do NOT cache failures — allow WordPress to retry on the next check cycle
            return false;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body );

        if ( ! is_object( $data ) || empty( $data->version ) || empty( $data->download_url ) ) {
            // Do NOT cache invalid data — allow retry on next check
            return false;
        }

        // Cache successful response for 12 hours
        set_transient( $this->cache_key, $data, 12 * HOUR_IN_SECONDS );

        return $data;
    }

    /**
     * Delete remote cache transient.
     */
    public function delete_transient_cache() {
        delete_transient( $this->cache_key );
    }

    /**
     * Inject update status into the WordPress updates transient.
     *
     * @param object $transient Site transient object.
     * @return object Modified site transient object.
     */
    public function check_update( $transient ) {
        if ( empty( $transient->checked ) ) {
            return $transient;
        }

        $remote = $this->get_remote_info();
        if ( ! $remote ) {
            return $transient;
        }

        // Compare versions
        $has_update = version_compare( ELEMENTFORGE_VERSION, $remote->version, '<' );

        $res = new \stdClass();
        $res->slug        = $this->slug;
        $res->plugin      = $this->plugin_basename;
        $res->new_version = $remote->version;
        $res->tested      = isset( $remote->tested ) ? $remote->tested : '';
        $res->requires    = isset( $remote->requires ) ? $remote->requires : '';
        $res->package     = $has_update ? $remote->download_url : '';
        $res->url         = isset( $remote->url ) ? $remote->url : '';

        if ( $has_update ) {
            $transient->response[ $this->plugin_basename ] = $res;
        } else {
            $transient->no_update[ $this->plugin_basename ] = $res;
        }

        return $transient;
    }

    /**
     * Provide details modal info when clicking "View version details".
     *
     * @param object|false $res    Default return value.
     * @param string       $action Action name.
     * @param object       $args   Request arguments.
     * @return object|false
     */
    public function plugin_popup_info( $res, $action, $args ) {
        if ( 'plugin_information' !== $action ) {
            return $res;
        }

        if ( empty( $args->slug ) || $this->slug !== $args->slug ) {
            return $res;
        }

        $remote = $this->get_remote_info();
        if ( ! $remote ) {
            return $res;
        }

        $res = new \stdClass();
        $res->name          = isset( $remote->name ) ? $remote->name : 'ElementForge';
        $res->slug          = $this->slug;
        $res->version       = $remote->version;
        $res->tested        = isset( $remote->tested ) ? $remote->tested : '';
        $res->requires      = isset( $remote->requires ) ? $remote->requires : '';
        $res->author        = isset( $remote->author ) ? $remote->author : 'ElementForge Team';
        $res->download_link = $remote->download_url;

        // Populate tabs
        $res->sections = [
            'description' => isset( $remote->sections->description ) ? $remote->sections->description : '',
            'changelog'   => isset( $remote->sections->changelog ) ? $remote->sections->changelog : '',
        ];

        return $res;
    }
}
