<?php
/**
 * ElementForge Loopback Diagnostics
 * 
 * Paste this snippet at the bottom of your theme's functions.php file on the development site.
 * Refresh the admin dashboard. Let's see if we can resolve the block by bypassing DNS/Cloudflare.
 */
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $ip = '115.70.226.115'; // Server IP
    $url = "http://{$ip}/elementforge/info.json";
    
    echo '<div class="notice notice-warning" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff; margin-top: 20px;">';
    echo '<h3>ElementForge Local Loopback Diagnostic</h3>';
    
    // Test direct IP connection with Host header
    echo '<p><strong>Testing direct IP connection bypassing Cloudflare (using Host header):</strong><br />';
    $response = wp_remote_get( $url, array(
        'timeout'    => 10,
        'sslverify'  => false,
        'headers'    => array(
            'Host'   => 'plugins.sitestaging.com.au',
            'Accept' => 'application/json'
        )
    ) );
    
    if ( is_wp_error( $response ) ) {
        echo '<span style="color: red;">❌ Direct IP connection failed: ' . esc_html( $response->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        echo '<span style="color: green;">✅ Direct IP Succeeded (HTTP Code ' . $code . ')</span><br />';
        echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 150px; overflow: auto;">' . esc_html( $body ) . '</pre>';
    }
    echo '</p>';
    echo '</div>';
});
