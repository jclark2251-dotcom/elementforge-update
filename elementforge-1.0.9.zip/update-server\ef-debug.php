<?php
/**
 * ElementForge Update Debugger
 *
 * DROP THIS FILE into the root of the WordPress site that isn't showing updates.
 * Access it via: https://yoursite.com/ef-debug.php
 *
 * It will:
 *  1. Show what URL the plugin is using for updates
 *  2. Show what is stored in the WordPress transient cache
 *  3. Attempt a live fetch of the update endpoint
 *  4. Clear stale transients so WordPress retries immediately
 *
 * DELETE THIS FILE after you're done — it's for one-time diagnostics only.
 */

// Bootstrap WordPress
define( 'ABSPATH_FOUND', true );
$wp_load = __DIR__ . '/wp-load.php';
if ( ! file_exists( $wp_load ) ) {
    die( 'ERROR: Cannot find wp-load.php. Make sure ef-debug.php is in the WordPress root directory (same folder as wp-config.php).' );
}
require_once $wp_load;

// Only allow admins to run this
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( 'You must be logged in as an administrator to run this script.' );
}

$update_url    = defined( 'ELEMENTFORGE_UPDATE_URL' ) ? ELEMENTFORGE_UPDATE_URL : 'NOT DEFINED — plugin may not be active or loaded';
$cache_key     = 'elementforge_remote_update_info';
$cached_value  = get_transient( $cache_key );
$wp_transient  = get_site_transient( 'update_plugins' );

// --- Clear transients ---
$cleared_ef   = delete_transient( $cache_key );
$cleared_site = delete_site_transient( 'update_plugins' );

// --- Live fetch from the update URL ---
$live_response = null;
$live_error    = null;
$live_json     = null;

if ( defined( 'ELEMENTFORGE_UPDATE_URL' ) ) {
    $response = wp_remote_get( ELEMENTFORGE_UPDATE_URL, [ 'timeout' => 15 ] );
    if ( is_wp_error( $response ) ) {
        $live_error = $response->get_error_message();
    } else {
        $live_response = wp_remote_retrieve_response_code( $response );
        $live_body     = wp_remote_retrieve_body( $response );
        $live_json     = json_decode( $live_body );
    }
}

// --- Output ---
header( 'Content-Type: text/plain; charset=utf-8' );

echo "=== ElementForge Update Debugger ===\n\n";

echo "--- Plugin Status ---\n";
echo "Plugin active:        " . ( defined( 'ELEMENTFORGE_VERSION' ) ? 'YES' : 'NO — plugin not loaded, make sure it is active on this site' ) . "\n";
echo "Plugin version:       " . ( defined( 'ELEMENTFORGE_VERSION' ) ? ELEMENTFORGE_VERSION : 'N/A' ) . "\n";
echo "Update URL constant:  " . $update_url . "\n\n";

echo "--- Transient Cache (before clearing) ---\n";
echo "elementforge_remote_update_info: ";
if ( false === $cached_value ) {
    echo "NOT SET (no cache)\n";
} elseif ( null === $cached_value ) {
    echo "NULL\n";
} else {
    echo "CACHED — version in cache: " . ( isset( $cached_value->version ) ? $cached_value->version : 'unknown' ) . "\n";
}

echo "\nWordPress update_plugins transient: ";
if ( ! $wp_transient ) {
    echo "NOT SET\n";
} else {
    $ef_entry = isset( $wp_transient->response['elementforge/elementforge.php'] )
        ? $wp_transient->response['elementforge/elementforge.php']
        : ( isset( $wp_transient->no_update['elementforge/elementforge.php'] ) ? '(in no_update list)' : 'NOT FOUND' );
    echo "EXISTS — ElementForge entry: ";
    if ( is_object( $ef_entry ) ) {
        echo "update available to v{$ef_entry->new_version}\n";
    } else {
        echo $ef_entry . "\n";
    }
}

echo "\n--- Transient Clear Results ---\n";
echo "Cleared elementforge cache:    " . ( $cleared_ef   ? 'YES' : 'nothing to clear (was already empty)' ) . "\n";
echo "Cleared update_plugins cache:  " . ( $cleared_site ? 'YES' : 'nothing to clear (was already empty)' ) . "\n";

echo "\n--- Live Fetch from Update URL ---\n";
if ( $live_error ) {
    echo "ERROR: " . $live_error . "\n";
} elseif ( $live_response ) {
    echo "HTTP Status:   " . $live_response . "\n";
    if ( $live_json ) {
        echo "Remote name:   " . ( $live_json->name ?? 'N/A' ) . "\n";
        echo "Remote version:" . ( $live_json->version ?? 'N/A' ) . "\n";
        echo "Download URL:  " . ( $live_json->download_url ?? 'N/A' ) . "\n";

        $local_ver  = defined( 'ELEMENTFORGE_VERSION' ) ? ELEMENTFORGE_VERSION : '0';
        $remote_ver = $live_json->version ?? '0';
        $has_update = version_compare( $local_ver, $remote_ver, '<' );
        echo "\nUpdate available? " . ( $has_update ? "YES — {$local_ver} → {$remote_ver}" : "NO — local ({$local_ver}) >= remote ({$remote_ver})" ) . "\n";
    } else {
        echo "INVALID JSON returned. Raw body:\n";
        echo $live_body . "\n";
    }
} else {
    echo "No response (URL constant not defined).\n";
}

echo "\n--- Next Steps ---\n";
echo "1. Transients have been cleared above.\n";
echo "2. Go to Dashboard -> Updates -> Check Again to force a fresh check.\n";
echo "3. DELETE this file (ef-debug.php) from your server root when done.\n";
