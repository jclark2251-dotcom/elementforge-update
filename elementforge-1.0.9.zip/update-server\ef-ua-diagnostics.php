<?php
/**
 * ElementForge Staging Connection Tester - User-Agent Test
 * 
 * Paste this snippet at the bottom of your theme's functions.php file on the development site.
 * Refresh the admin dashboard. Let's see if Cloudflare is blocking based on User-Agent or the IP itself.
 */
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $update_url = 'https://plugins.sitestaging.com.au/elementforge/info.json';
    
    echo '<div class="notice notice-warning" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff; margin-top: 20px;">';
    echo '<h3>ElementForge User-Agent Spoofing Diagnostics</h3>';
    
    // Test with browser User-Agent
    echo '<p><strong>Testing wp_remote_get with Browser User-Agent:</strong><br />';
    $response = wp_remote_get( $update_url, array(
        'timeout'    => 15,
        'sslverify'  => false,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 (ElementForge Updater)'
    ) );
    
    if ( is_wp_error( $response ) ) {
        echo '<span style="color: red;">❌ Failed: ' . esc_html( $response->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        if ( $code === 200 ) {
            echo '<span style="color: green;">✅ Succeeded (HTTP Code 200)</span><br />';
            echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 150px; overflow: auto;">' . esc_html( $body ) . '</pre>';
        } else {
            echo '<span style="color: red;">❌ Failed with HTTP Code ' . $code . '</span><br />';
            if ( strpos( $body, 'Cloudflare' ) !== false ) {
                echo '<span style="color: red;">Blocked by Cloudflare Challenge Page.</span>';
            }
        }
    }
    echo '</p>';
    echo '</div>';
});
