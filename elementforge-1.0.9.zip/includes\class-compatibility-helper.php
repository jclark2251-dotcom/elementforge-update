<?php
namespace ElementForge\Includes;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Compatibility_Helper {
    
    /**
     * Check if Elementor is installed and active.
     *
     * @return bool
     */
    public static function is_elementor_active() {
        return did_action( 'elementor/loaded' );
    }

    /**
     * Get the active Elementor version.
     *
     * @return string
     */
    public static function get_elementor_version() {
        return defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '0.0.0';
    }

    /**
     * Compare Elementor versions.
     *
     * @param string $version
     * @param string $compare
     * @return bool
     */
    public static function version_compare( $version, $compare = '>=' ) {
        return version_compare( self::get_elementor_version(), $version, $compare );
    }

    /**
     * Get the correct widget registration hook.
     * Elementor 3.5.0 deprecated 'elementor/widgets/widgets_registered' in favor of 'elementor/widgets/register'.
     *
     * @return string
     */
    public static function get_registration_hook() {
        return self::version_compare( '3.5.0' ) ? 'elementor/widgets/register' : 'elementor/widgets/widgets_registered';
    }

    /**
     * Safe wrapper to register widgets.
     *
     * @param \Elementor\Widgets_Manager $widgets_manager
     * @param \Elementor\Widget_Base $widget_instance
     */
    public static function register_widget( $widgets_manager, $widget_instance ) {
        if ( self::version_compare( '3.5.0' ) ) {
            $widgets_manager->register( $widget_instance );
        } else {
            $widgets_manager->register_widget_type( $widget_instance );
        }
    }
}
