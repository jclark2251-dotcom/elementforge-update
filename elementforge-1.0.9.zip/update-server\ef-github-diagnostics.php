<?php
/**
 * ElementForge GitHub Diagnostics
 * 
 * Paste this snippet at the bottom of your theme's functions.php file on the development site.
 * Let's test if the server can connect to GitHub raw files.
 */
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $url = 'https://raw.githubusercontent.com/octocat/Spoon-Knife/master/README.md';
    
    echo '<div class="notice notice-warning" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff; margin-top: 20px;">';
    echo '<h3>ElementForge GitHub Connection Test</h3>';
    
    echo '<p><strong>Testing connection to GitHub raw servers:</strong><br />';
    $response = wp_remote_get( $url, array( 'timeout' => 10 ) );
    
    if ( is_wp_error( $response ) ) {
        echo '<span style="color: red;">❌ Failed to reach GitHub: ' . esc_html( $response->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        echo '<span style="color: green;">✅ Succeeded (HTTP Code ' . $code . ')</span><br />';
        echo '<p>If this succeeded, we can host the update files on GitHub to completely bypass the staging server loopback firewall issues!</p>';
    }
    echo '</p>';
    echo '</div>';
});
