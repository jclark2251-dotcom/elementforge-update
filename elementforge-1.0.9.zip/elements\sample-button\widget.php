<?php
namespace ElementForge\Elements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Sample_Button extends \Elementor\Widget_Base {

    public function get_name() {
        return 'sample-button';
    }

    public function get_title() {
        return esc_html__( 'Forge Button', 'elementforge' );
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return [ 'forge-elements' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'Content', 'elementforge' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'       => esc_html__( 'Button Text', 'elementforge' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Click Me', 'elementforge' ),
                'placeholder' => esc_html__( 'Type button text here', 'elementforge' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label'   => esc_html__( 'Link', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url'         => '#',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute( 'button', 'class', 'elementforge-button' );
        if ( ! empty( $settings['button_link']['url'] ) ) {
            $this->add_link_attributes( 'button', $settings['button_link'] );
        }
        ?>
        <div class="elementforge-button-wrapper">
            <a <?php $this->print_render_attribute_string( 'button' ); ?>>
                <?php echo esc_html( $settings['button_text'] ); ?>
            </a>
        </div>
        <?php
    }
}
