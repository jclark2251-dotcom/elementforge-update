<?php
namespace ElementForge\Admin;

use ElementForge\Includes\Element_Loader;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin_Page {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init() {
        add_action( 'admin_menu', [ $this, 'register_settings_page' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
    }

    public function register_settings_page() {
        add_menu_page(
            __( 'ElementForge Settings', 'elementforge' ),
            'ElementForge',
            'manage_options',
            'elementforge',
            [ $this, 'render_admin_page' ],
            'dashicons-hammer',
            99
        );
    }

    public function register_settings() {
        register_setting(
            'elementforge_settings_group',
            'ef_active_elements',
            [
                'type'              => 'array',
                'sanitize_callback' => [ $this, 'sanitize_enabled_elements' ],
                'default'           => []
            ]
        );
    }

    /**
     * Sanitize settings and clear transient cache.
     */
    public function sanitize_enabled_elements( $input ) {
        $sanitized = [];
        if ( is_array( $input ) ) {
            foreach ( $input as $key => $value ) {
                $sanitized[ sanitize_key( $key ) ] = (bool) $value;
            }
        }

        // Clear transient to force cache rebuild on next load
        Element_Loader::instance()->clear_cache();
        Element_Loader::instance()->rebuild_active_elements_cache();

        return $sanitized;
    }

    public function enqueue_styles( $hook ) {
        if ( 'toplevel_page_elementforge' !== $hook ) {
            return;
        }

        wp_enqueue_style(
            'elementforge-admin-css',
            ELEMENTFORGE_URL . 'admin/css/admin.css',
            [],
            ELEMENTFORGE_VERSION
        );
    }

    public function render_admin_page() {
        $loader             = Element_Loader::instance();
        $available_elements = $loader->get_all_available_elements();
        $enabled_elements   = get_option( 'ef_active_elements', [] );
        ?>
        <div id="elementforge-admin-wrap" class="wrap">
            <header class="ef-header">
                <div class="ef-header-title">
                    <span class="ef-logo-icon">⚒</span>
                    <h1>ElementForge <span class="ef-version">v<?php echo esc_html( ELEMENTFORGE_VERSION ); ?></span></h1>
                </div>
                <p class="ef-tagline"><?php esc_html_e( 'Forge lightweight and modular widgets for your Elementor projects.', 'elementforge' ); ?></p>
            </header>

            <form method="post" action="options.php" class="ef-settings-form">
                <?php
                settings_fields( 'elementforge_settings_group' );
                do_settings_sections( 'elementforge_settings_group' );
                ?>

                <div class="ef-section-header">
                    <h2><?php esc_html_e( 'Widgets Control Panel', 'elementforge' ); ?></h2>
                    <p><?php esc_html_e( 'Toggle widgets ON or OFF. Disabled widgets do not register or load their code, ensuring zero performance overhead.', 'elementforge' ); ?></p>
                </div>

                <?php if ( empty( $available_elements ) ) : ?>
                    <div class="ef-alert ef-alert-info">
                        <p><?php esc_html_e( 'No modular elements found in elements directory. Drop widgets folder in elements/ to get started.', 'elementforge' ); ?></p>
                    </div>
                <?php else : ?>
                    <div class="ef-grid">
                        <?php foreach ( $available_elements as $id => $manifest ) : 
                            $is_checked  = ! empty( $enabled_elements[ $id ] );
                            $name         = isset( $manifest['name'] ) ? $manifest['name'] : $id;
                            $preview_url  = ELEMENTFORGE_URL . 'elements/' . $id . '/preview.png';
                            if ( ! file_exists( ELEMENTFORGE_PATH . 'elements/' . $id . '/preview.png' ) ) {
                                $preview_url = ELEMENTFORGE_URL . 'admin/images/placeholder.png';
                            }
                            ?>
                            <div class="ef-card <?php echo $is_checked ? 'ef-card-active' : ''; ?>">
                                <div class="ef-card-preview-wrap">
                                    <img src="<?php echo esc_url( $preview_url ); ?>" alt="<?php echo esc_attr( $name ); ?>" class="ef-card-preview" />
                                </div>
                                <div class="ef-card-body">
                                    <div class="ef-card-header">
                                        <h3 class="ef-card-title"><?php echo esc_html( $name ); ?></h3>
                                        <label class="ef-switch">
                                            <input type="checkbox" 
                                                   name="ef_active_elements[<?php echo esc_attr( $id ); ?>]" 
                                                   value="1" 
                                                   <?php checked( $is_checked, true ); ?> />
                                            <span class="ef-slider"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="ef-form-actions">
                    <?php submit_button( __( 'Save Forge Settings', 'elementforge' ), 'primary ef-submit-btn' ); ?>
                </div>
            </form>
        </div>
        <?php
    }
}
