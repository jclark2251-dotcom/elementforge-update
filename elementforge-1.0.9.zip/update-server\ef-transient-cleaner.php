<?php
/**
 * Plugin Name: EF Transient Cleaner
 * Description: Clears ElementForge update transients. Delete after use.
 * Version: 1.0
 */
delete_transient( 'elementforge_remote_update_info' );
delete_site_transient( 'update_plugins' );
wp_die( '<h2>✅ Done!</h2><p>ElementForge transients cleared. <strong>Now deactivate and delete this plugin</strong>, then go to Dashboard → Updates → Check Again.</p><p><a href="' . admin_url('plugins.php') . '">Go to Plugins</a></p>' );
