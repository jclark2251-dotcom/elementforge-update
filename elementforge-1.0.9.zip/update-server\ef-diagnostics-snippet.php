<?php
/**
 * ElementForge Staging Connection Tester
 * 
 * Paste this snippet at the very bottom of your theme's functions.php file on the development site.
 * Then visit any page on your development site admin dashboard.
 * It will display diagnostic information at the top of the screen.
 * Once you see the output, copy it here, and remove this snippet from functions.php.
 */
add_action( 'admin_notices', function() {
    // Only run for administrators
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $update_url = 'https://plugins.sitestaging.com.au/elementforge/info.json';
    
    echo '<div class="notice notice-warning is-dismissible" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff;">';
    echo '<h3>ElementForge Update Debugger Diagnostic</h3>';
    
    // 1. Test standard WordPress HTTP request
    echo '<p><strong>1. Testing WordPress wp_remote_get to Update URL:</strong><br />';
    $response = wp_remote_get( $update_url, array( 'timeout' => 15 ) );
    
    if ( is_wp_error( $response ) ) {
        echo '<span style="color: red;">❌ wp_remote_get Failed: ' . esc_html( $response->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        echo '<span style="color: green;">✅ wp_remote_get Succeeded (HTTP Code: ' . $code . ')</span><br />';
        echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 150px; overflow: auto;">' . esc_html( $body ) . '</pre>';
    }
    echo '</p>';

    // 2. Test WordPress HTTP request with SSL verification disabled
    echo '<p><strong>2. Testing wp_remote_get with sslverify => false:</strong><br />';
    $response_no_ssl = wp_remote_get( $update_url, array( 'timeout' => 15, 'sslverify' => false ) );
    
    if ( is_wp_error( $response_no_ssl ) ) {
        echo '<span style="color: red;">❌ wp_remote_get (No SSL verify) Failed: ' . esc_html( $response_no_ssl->get_error_message() ) . '</span>';
    } else {
        $code_no_ssl = wp_remote_retrieve_response_code( $response_no_ssl );
        echo '<span style="color: green;">✅ wp_remote_get (No SSL verify) Succeeded (HTTP Code: ' . $code_no_ssl . ')</span>';
    }
    echo '</p>';

    // 3. Output current local plugin details
    echo '<p><strong>3. Current Local Environment:</strong><br />';
    echo 'Installed ELEMENTFORGE_VERSION: ' . (defined('ELEMENTFORGE_VERSION') ? esc_html(ELEMENTFORGE_VERSION) : 'Not defined') . '<br />';
    echo 'Update URL Defined: ' . (defined('ELEMENTFORGE_UPDATE_URL') ? esc_html(ELEMENTFORGE_UPDATE_URL) : 'Not defined') . '<br />';
    echo 'PHP version: ' . phpversion() . '<br />';
    echo 'WordPress version: ' . get_bloginfo('version') . '<br />';
    echo '</p>';
    
    echo '</div>';
});
