<?php
namespace ElementForge\Includes;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Element_Loader {

    private static $instance = null;

    /**
     * Active elements loaded from transient/database.
     * array of element_id => [ 'file' => path, 'class' => class_name ]
     */
    private $active_elements = null;

    /**
     * Singleton instance.
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Initialize the loader hooks.
     */
    public function init() {
        // Register the elementor widget hook
        if ( Compatibility_Helper::is_elementor_active() ) {
            $hook = Compatibility_Helper::get_registration_hook();
            add_action( $hook, [ $this, 'register_active_widgets' ] );

            // Register custom elements category
            add_action( 'elementor/elements/categories_registered', [ $this, 'register_custom_categories' ] );
        }
    }

    /**
     * Register a custom category for ElementForge elements in Elementor panel.
     *
     * @param \Elementor\Elements_Manager $elements_manager
     */
    public function register_custom_categories( $elements_manager ) {
        $elements_manager->add_category(
            'forge-elements',
            [
                'title' => esc_html__( 'Forge Elements', 'elementforge' ),
                'icon'  => 'eicon-font',
            ]
        );
    }

    /**
     * Load the active elements, from transient or database/filesystem scan.
     *
     * @return array
     */
    public function get_active_elements() {
        if ( ! is_null( $this->active_elements ) ) {
            return $this->active_elements;
        }

        // Try transient first
        $cached = get_transient( 'elementforge_active_elements_cache' );
        if ( false !== $cached ) {
            $this->active_elements = $cached;
            return $this->active_elements;
        }

        // Not cached or expired: Scan and rebuild
        $this->active_elements = $this->rebuild_active_elements_cache();
        return $this->active_elements;
    }

    /**
     * Scan /elements/ directory and fetch active widgets metadata.
     *
     * @return array
     */
    public function rebuild_active_elements_cache() {
        $elements_dir = ELEMENTFORGE_PATH . 'elements/';
        $active_elements = [];

        // If directory doesn't exist, return empty
        if ( ! is_dir( $elements_dir ) ) {
            return $active_elements;
        }

        // Get enabled status from options.
        $options = get_option( 'ef_active_elements', [] );

        // Scan folders in elements/
        $dirs = glob( $elements_dir . '*', GLOB_ONLYDIR );
        if ( ! empty( $dirs ) ) {
            foreach ( $dirs as $dir ) {
                $manifest_file = $dir . '/manifest.json';
                $widget_file   = $dir . '/widget.php';

                if ( file_exists( $manifest_file ) && file_exists( $widget_file ) ) {
                    $manifest_content = @file_get_contents( $manifest_file );
                    if ( $manifest_content ) {
                        $manifest = json_decode( $manifest_content, true );

                        if ( is_array( $manifest ) && isset( $manifest['id'], $manifest['class'] ) ) {
                            $id = $manifest['id'];

                            // Check if explicitly enabled.
                            $is_enabled = ! empty( $options[ $id ] );

                            if ( $is_enabled ) {
                                $active_elements[ $id ] = [
                                    'file'  => $widget_file,
                                    'class' => $manifest['class']
                                ];
                            }
                        }
                    }
                }
            }
        }

        // Store in transient for 24 hours (or indefinitely, but we clear it when options change)
        set_transient( 'elementforge_active_elements_cache', $active_elements, DAY_IN_SECONDS );

        return $active_elements;
    }

    /**
     * Scan elements/ directory to get ALL available elements (for settings page).
     *
     * @return array
     */
    public function get_all_available_elements() {
        $elements_dir = ELEMENTFORGE_PATH . 'elements/';
        $available    = [];

        if ( ! is_dir( $elements_dir ) ) {
            return $available;
        }

        $dirs = glob( $elements_dir . '*', GLOB_ONLYDIR );
        if ( ! empty( $dirs ) ) {
            foreach ( $dirs as $dir ) {
                $manifest_file = $dir . '/manifest.json';
                if ( file_exists( $manifest_file ) ) {
                    $manifest_content = @file_get_contents( $manifest_file );
                    if ( $manifest_content ) {
                        $manifest = json_decode( $manifest_content, true );
                        if ( is_array( $manifest ) && isset( $manifest['id'] ) ) {
                            $available[ $manifest['id'] ] = $manifest;
                        }
                    }
                }
            }
        }

        return $available;
    }

    /**
     * Clear the cache transient.
     */
    public function clear_cache() {
        delete_transient( 'elementforge_active_elements_cache' );
        $this->active_elements = null;
    }

    /**
     * Registers active widgets into Elementor.
     * Hooks into elementor/widgets/register or elementor/widgets/widgets_registered.
     *
     * @param \Elementor\Widgets_Manager|null $widgets_manager
     */
    public function register_active_widgets( $widgets_manager = null ) {
        if ( ! Compatibility_Helper::is_elementor_active() ) {
            return;
        }

        if ( ! $widgets_manager ) {
            $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
        }

        $active = $this->get_active_elements();

        if ( ! empty( $active ) ) {
            foreach ( $active as $id => $widget_info ) {
                if ( file_exists( $widget_info['file'] ) ) {
                    require_once $widget_info['file'];
                    $class = $widget_info['class'];
                    if ( class_exists( $class ) ) {
                        Compatibility_Helper::register_widget( $widgets_manager, new $class() );
                    }
                }
            }
        }
    }
}
