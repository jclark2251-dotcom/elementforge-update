<?php
/**
 * Forge Hero Banner Widget
 *
 * Full-featured hero section with heading, subheading, main content,
 * optional dual CTA buttons, hero image, optional badge, wave divider,
 * a customizable features band, and an interactive particle background.
 */

namespace ElementForge\Elements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Hero_Banner extends \Elementor\Widget_Base {

    /* ─── Identity ─────────────────────────────── */

    public function get_name() {
        return 'hero-banner';
    }

    public function get_title() {
        return esc_html__( 'Forge Hero Banner', 'elementforge' );
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return [ 'forge-elements' ];
    }

    public function get_style_depends() {
        wp_register_style(
            'ef-hero-banner-fonts',
            'https://fonts.googleapis.com/css2?family=Poppins:wght@600;700;800&family=Inter:wght@400;500;600&display=swap',
            [],
            null
        );
        wp_register_style(
            'ef-hero-banner-style',
            ELEMENTFORGE_URL . 'elements/hero-banner/style.css',
            [ 'ef-hero-banner-fonts' ],
            ELEMENTFORGE_VERSION
        );
        return [ 'ef-hero-banner-style' ];
    }

    /* ═══════════════════════════════════════════
     *  CONTROLS
     * ═══════════════════════════════════════════ */

    protected function register_controls() {

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Hero Content            │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_hero_content', [
            'label' => esc_html__( 'Hero Content', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'heading', [
            'label'       => esc_html__( 'Heading', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => 'Lorem Ipsum Dolor <br><span class="highlight">Delivered to You.</span>',
            'label_block' => true,
            'rows'        => 3,
            'description' => esc_html__( 'Supports HTML tags like <br>, <span>, and <strong>.', 'elementforge' ),
        ] );

        $this->add_control( 'subheading', [
            'label'       => esc_html__( 'Sub-heading', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
            'rows'        => 2,
            'description' => esc_html__( 'Supports HTML tags.', 'elementforge' ),
        ] );

        $this->add_control( 'subheading_position', [
            'label'   => esc_html__( 'Subheading Position', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'above' => [
                    'title' => esc_html__( 'Above Heading', 'elementforge' ),
                    'icon'  => 'eicon-v-align-top',
                ],
                'below' => [
                    'title' => esc_html__( 'Below Heading', 'elementforge' ),
                    'icon'  => 'eicon-v-align-bottom',
                ],
            ],
            'default' => 'below',
            'toggle'  => false,
        ] );

        $this->add_control( 'content', [
            'label'       => esc_html__( 'Content', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
            'rows'        => 4,
            'description' => esc_html__( 'Main description content under subheading.', 'elementforge' ),
        ] );

        $this->end_controls_section();

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Checklist               │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_checklist', [
            'label' => esc_html__( 'Checklist', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'checklist_icon', [
            'label'   => esc_html__( 'Checklist Icon', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::ICONS,
            'default' => [
                'value'   => 'fas fa-check',
                'library' => 'fa-solid',
            ],
        ] );

        $checklist_repeater = new \Elementor\Repeater();
        $checklist_repeater->add_control( 'checklist_text', [
            'label'       => esc_html__( 'Text', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => 'Lorem ipsum dolor sit amet',
            'label_block' => true,
        ] );

        $this->add_control( 'checklist_items', [
            'label'       => esc_html__( 'Checklist Items', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::REPEATER,
            'fields'      => $checklist_repeater->get_controls(),
            'default'     => [
                [ 'checklist_text' => 'Consectetur adipiscing elit sed do' ],
                [ 'checklist_text' => 'Eiusmod tempor incididunt labore' ],
                [ 'checklist_text' => 'Ut enim ad minim veniam nostrud' ],
            ],
            'title_field' => '{{{ checklist_text }}}',
        ] );

        $this->end_controls_section();

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Buttons                 │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_buttons', [
            'label' => esc_html__( 'Call to Action Buttons', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_btn_primary', [
            'label'        => esc_html__( 'Show Primary Button', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'elementforge' ),
            'label_off'    => esc_html__( 'Hide', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'btn_primary_text', [
            'label'     => esc_html__( 'Primary Button Text', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'default'   => 'Shop Now',
            'condition' => [ 'show_btn_primary' => 'yes' ],
        ] );

        $this->add_control( 'btn_primary_link', [
            'label'       => esc_html__( 'Primary Button Link', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::URL,
            'default'     => [ 'url' => '#' ],
            'placeholder' => 'https://your-link.com',
            'condition'   => [ 'show_btn_primary' => 'yes' ],
        ] );

        $this->add_control( 'btn_primary_icon', [
            'label'     => esc_html__( 'Primary Button Icon', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::ICONS,
            'default'   => [
                'value'   => 'fas fa-shopping-cart',
                'library' => 'fa-solid',
            ],
            'condition' => [ 'show_btn_primary' => 'yes' ],
        ] );

        $this->add_control( 'hr_btn', [
            'type'      => \Elementor\Controls_Manager::DIVIDER,
            'condition' => [ 'show_btn_primary' => 'yes' ],
        ] );

        $this->add_control( 'show_btn_secondary', [
            'label'        => esc_html__( 'Show Secondary Button', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'elementforge' ),
            'label_off'    => esc_html__( 'Hide', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'btn_secondary_text', [
            'label'     => esc_html__( 'Secondary Button Text', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::TEXT,
            'default'   => 'Learn More',
            'condition' => [ 'show_btn_secondary' => 'yes' ],
        ] );

        $this->add_control( 'btn_secondary_link', [
            'label'       => esc_html__( 'Secondary Button Link', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::URL,
            'default'     => [ 'url' => '#' ],
            'placeholder' => 'https://your-link.com',
            'condition'   => [ 'show_btn_secondary' => 'yes' ],
        ] );

        $this->add_control( 'btn_secondary_icon', [
            'label'     => esc_html__( 'Secondary Button Icon', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::ICONS,
            'default'   => [
                'value'   => 'fas fa-chevron-right',
                'library' => 'fa-solid',
            ],
            'condition' => [ 'show_btn_secondary' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Hero Image & Badge      │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_hero_image', [
            'label' => esc_html__( 'Hero Image & Badge', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'hero_image', [
            'label'   => esc_html__( 'Hero Image', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ] );

        $this->add_control( 'hero_image_layout', [
            'label'   => esc_html__( 'Image Position', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::CHOOSE,
            'options' => [
                'left'  => [
                    'title' => esc_html__( 'Left', 'elementforge' ),
                    'icon'  => 'eicon-h-align-left',
                ],
                'right' => [
                    'title' => esc_html__( 'Right', 'elementforge' ),
                    'icon'  => 'eicon-h-align-right',
                ],
            ],
            'default' => 'right',
            'prefix_class' => 'ef-hero-image-',
        ] );

        $this->add_control( 'hr_badge', [ 'type' => \Elementor\Controls_Manager::DIVIDER ] );

        $this->add_control( 'show_badge', [
            'label'        => esc_html__( 'Show Badge', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->add_control( 'badge_image', [
            'label'     => esc_html__( 'Badge Image', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::MEDIA,
            'default'   => [ 'url' => '' ],
            'condition' => [ 'show_badge' => 'yes' ],
        ] );

        $this->end_controls_section();

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Features Band           │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_features', [
            'label' => esc_html__( 'Features Band', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_features', [
            'label'        => esc_html__( 'Show Features Band', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $features_repeater = new \Elementor\Repeater();
        $features_repeater->add_control( 'feature_icon', [
            'label'   => esc_html__( 'Icon', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::ICONS,
            'default' => [
                'value'   => 'fas fa-star',
                'library' => 'fa-solid',
            ],
        ] );

        $features_repeater->add_control( 'feature_title', [
            'label'       => esc_html__( 'Title', 'elementforge' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => 'Feature Title',
            'label_block' => true,
        ] );

        $features_repeater->add_control( 'feature_desc', [
            'label'   => esc_html__( 'Description', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::TEXTAREA,
            'default' => 'Lorem ipsum dolor sit amet consectetur.',
            'rows'    => 2,
        ] );

        $this->add_control( 'features', [
            'label'     => esc_html__( 'Features', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::REPEATER,
            'fields'    => $features_repeater->get_controls(),
            'default'   => [
                [
                    'feature_icon'  => [ 'value' => 'fas fa-tint', 'library' => 'fa-solid' ],
                    'feature_title' => 'Pure & Natural',
                    'feature_desc'  => 'Sourced from sandstone mountains.',
                ],
                [
                    'feature_icon'  => [ 'value' => 'fas fa-truck', 'library' => 'fa-solid' ],
                    'feature_title' => 'On-Time Delivery',
                    'feature_desc'  => 'Weekly or fortnightly deliveries.',
                ],
                [
                    'feature_icon'  => [ 'value' => 'fas fa-leaf', 'library' => 'fa-solid' ],
                    'feature_title' => 'Eco Friendly',
                    'feature_desc'  => 'BPA-free bottles & sustainable.',
                ],
                [
                    'feature_icon'  => [ 'value' => 'fas fa-heart', 'library' => 'fa-solid' ],
                    'feature_title' => 'Family Owned',
                    'feature_desc'  => 'Over 20 years of trusted service.',
                ],
            ],
            'title_field' => '{{{ feature_title }}}',
            'condition'   => [ 'show_features' => 'yes' ],
        ] );

        $this->add_control( 'features_layout_divider', [
            'type'      => \Elementor\Controls_Manager::DIVIDER,
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        // Features row count - responsive
        $this->add_responsive_control( 'features_columns', [
            'label'     => esc_html__( 'Columns Per Row', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'options'   => [
                '1' => esc_html__( '1 Column', 'elementforge' ),
                '2' => esc_html__( '2 Columns', 'elementforge' ),
                '3' => esc_html__( '3 Columns', 'elementforge' ),
                '4' => esc_html__( '4 Columns', 'elementforge' ),
            ],
            'default'   => '4',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .features-inner' => '--ef-features-cols: {{VALUE}};',
            ],
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        // Features layout alignment
        $this->add_control( 'features_alignment', [
            'label'     => esc_html__( 'Features Alignment', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'left' => [
                    'title' => esc_html__( 'Left', 'elementforge' ),
                    'icon'  => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'elementforge' ),
                    'icon'  => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__( 'Right', 'elementforge' ),
                    'icon'  => 'eicon-text-align-right',
                ],
            ],
            'default'   => 'left',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature' => 'text-align: {{VALUE}};',
            ],
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        // Features Icon Position
        $this->add_control( 'features_icon_position', [
            'label'     => esc_html__( 'Icon Position', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'options'   => [
                'side' => esc_html__( 'Side of Text', 'elementforge' ),
                'top'  => esc_html__( 'Above Heading', 'elementforge' ),
            ],
            'default'   => 'side',
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        $this->add_control( 'hr_shape_divider_sep', [
            'type' => \Elementor\Controls_Manager::DIVIDER,
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        $this->add_control( 'show_shape_divider', [
            'label'        => esc_html__( 'Enable Shape Divider', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
            'condition'    => [ 'show_features' => 'yes' ],
            'description'  => esc_html__( 'Show a decorative shape divider between the hero content and the features band.', 'elementforge' ),
        ] );

        $this->add_control( 'shape_divider_type', [
            'label'     => esc_html__( 'Shape Type', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SELECT,
            'options'   => [
                'wave'       => esc_html__( 'Wave', 'elementforge' ),
                'wave-multi' => esc_html__( 'Waves (Multi)', 'elementforge' ),
                'triangle'   => esc_html__( 'Triangle', 'elementforge' ),
                'tilt'       => esc_html__( 'Tilt', 'elementforge' ),
                'arrow'      => esc_html__( 'Arrow', 'elementforge' ),
                'curve'      => esc_html__( 'Curve', 'elementforge' ),
                'mountains'  => esc_html__( 'Mountains', 'elementforge' ),
                'zigzag'     => esc_html__( 'Zigzag', 'elementforge' ),
                'clouds'     => esc_html__( 'Clouds', 'elementforge' ),
                'drops'      => esc_html__( 'Drops', 'elementforge' ),
            ],
            'default'   => 'wave',
            'condition' => [
                'show_features' => 'yes',
                'show_shape_divider' => 'yes',
            ],
            'render_type' => 'template',
        ] );

        $this->end_controls_section();

        /* ┌────────────────────────────────────────┐
         * │  CONTENT TAB — Particles Toggle        │
         * └────────────────────────────────────────┘ */

        $this->start_controls_section( 'section_particles_content', [
            'label' => esc_html__( 'Particle Background', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
        ] );

        $this->add_control( 'show_particles', [
            'label'        => esc_html__( 'Enable Particles', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => 'yes',
        ] );

        $this->end_controls_section();


        /* ═══════════════════════════════════════════
         *  STYLE TAB — Background & Overlay
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_background', [
            'label' => esc_html__( 'Background & Overlay', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'hero_background',
                'label'    => esc_html__( 'Background', 'elementforge' ),
                'types'    => [ 'classic', 'gradient', 'video', 'slideshow' ],
                'selector' => '{{WRAPPER}} .ef-element-hero-banner',
            ]
        );

        $this->add_control( 'hr_bg_overlay', [
            'label' => esc_html__( 'Background Overlay', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'hero_background_overlay',
                'label'    => esc_html__( 'Background Overlay', 'elementforge' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .ef-element-hero-banner-overlay',
            ]
        );

        $this->add_control( 'hero_background_overlay_opacity', [
            'label'     => esc_html__( 'Overlay Opacity', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 0, 'max' => 1, 'step' => 0.05 ],
            ],
            'default'   => [ 'size' => 0.5 ],
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner-overlay' => 'opacity: {{SIZE}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_min_height', [
            'label'      => esc_html__( 'Minimum Height', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'vh' ],
            'range'      => [
                'px' => [ 'min' => 200, 'max' => 1200 ],
                'vh' => [ 'min' => 20,  'max' => 100 ],
            ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner' => 'min-height: {{SIZE}}{{UNIT}};',
            ],
            'separator'  => 'before',
        ] );

        $this->add_responsive_control( 'hero_padding', [
            'label'      => esc_html__( 'Content Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Typography & Colours
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_typography', [
            'label' => esc_html__( 'Typography & Colours', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        // Heading style controls
        $this->add_control( 'heading_style_label', [
            'label' => esc_html__( 'Heading Style', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
        ] );

        $this->add_control( 'heading_color', [
            'label'     => esc_html__( 'Heading Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-heading' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'heading_typography',
                'label'    => esc_html__( 'Heading Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-heading',
            ]
        );

        // Subheading style controls
        $this->add_control( 'subheading_style_label', [
            'label' => esc_html__( 'Subheading Style', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'subheading_color', [
            'label'     => esc_html__( 'Sub-heading Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#44546b',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-sub' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'subheading_typography',
                'label'    => esc_html__( 'Subheading Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-sub',
            ]
        );

        // Content body styles
        $this->add_control( 'content_style_label', [
            'label' => esc_html__( 'Content Body Style', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'content_color', [
            'label'     => esc_html__( 'Content Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#44546b',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-content' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'content_typography',
                'label'    => esc_html__( 'Content Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-content',
            ]
        );

        // Checklist styles
        $this->add_control( 'checklist_style_label', [
            'label' => esc_html__( 'Checklist Style', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'checklist_text_color', [
            'label'     => esc_html__( 'Checklist Text Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-checklist li' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'checklist_typography',
                'label'    => esc_html__( 'Checklist Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-checklist li',
            ]
        );

        $this->add_control( 'check_icon_bg', [
            'label'     => esc_html__( 'Check Icon Background', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#f7a823',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .check-icon' => 'background: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'check_icon_color', [
            'label'     => esc_html__( 'Check Icon Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .check-icon' => 'color: {{VALUE}};',
                '{{WRAPPER}} .ef-element-hero-banner .check-icon svg' => 'color: {{VALUE}}; fill: {{VALUE}}; stroke: {{VALUE}};',
            ],
        ] );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Buttons
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_buttons', [
            'label' => esc_html__( 'Buttons Styling', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        // Primary Button Styles
        $this->add_control( 'btn_primary_style_label', [
            'label' => esc_html__( 'Primary Button', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'btn_primary_typography',
                'label'    => esc_html__( 'Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-primary',
            ]
        );

        $this->start_controls_tabs( 'btn_primary_tabs' );
        $this->start_controls_tab( 'btn_primary_normal_tab', [ 'label' => esc_html__( 'Normal', 'elementforge' ) ] );

        $this->add_control( 'btn_primary_bg_color', [
            'label'     => esc_html__( 'Background Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-primary' => 'background: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'btn_primary_text_color', [
            'label'     => esc_html__( 'Text Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-primary' => 'color: {{VALUE}};',
            ],
        ] );

        $this->end_controls_tab();

        $this->start_controls_tab( 'btn_primary_hover_tab', [ 'label' => esc_html__( 'Hover', 'elementforge' ) ] );

        $this->add_control( 'btn_primary_bg_color_hover', [
            'label'     => esc_html__( 'Background Colour (Hover)', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0a2342',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-primary:hover' => 'background: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'btn_primary_text_color_hover', [
            'label'     => esc_html__( 'Text Colour (Hover)', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-primary:hover' => 'color: {{VALUE}};',
            ],
        ] );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'btn_primary_border',
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-primary',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'btn_primary_box_shadow',
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-primary',
            ]
        );

        // Secondary Button Styles
        $this->add_control( 'btn_secondary_style_label', [
            'label' => esc_html__( 'Secondary Button', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'btn_secondary_typography',
                'label'    => esc_html__( 'Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-outline',
            ]
        );

        $this->start_controls_tabs( 'btn_secondary_tabs' );
        $this->start_controls_tab( 'btn_secondary_normal_tab', [ 'label' => esc_html__( 'Normal', 'elementforge' ) ] );

        $this->add_control( 'btn_secondary_bg_color', [
            'label'     => esc_html__( 'Background Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => 'transparent',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-outline' => 'background: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'btn_secondary_text_color', [
            'label'     => esc_html__( 'Text Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-outline' => 'color: {{VALUE}};',
            ],
        ] );

        $this->end_controls_tab();

        $this->start_controls_tab( 'btn_secondary_hover_tab', [ 'label' => esc_html__( 'Hover', 'elementforge' ) ] );

        $this->add_control( 'btn_secondary_bg_color_hover', [
            'label'     => esc_html__( 'Background (Hover)', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => 'rgba(14, 44, 82, 0.05)',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-outline:hover' => 'background: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'btn_secondary_text_color_hover', [
            'label'     => esc_html__( 'Text Colour (Hover)', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .btn-outline:hover' => 'color: {{VALUE}};',
            ],
        ] );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'btn_secondary_border',
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-outline',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'btn_secondary_box_shadow',
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .btn-outline',
            ]
        );

        // General button sizing
        $this->add_control( 'btn_sizing_label', [
            'label' => esc_html__( 'Button Sizing', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_responsive_control( 'btn_border_radius', [
            'label'      => esc_html__( 'Button Border Radius', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
                'px' => [ 'min' => 0, 'max' => 50 ],
            ],
            'default'    => [ 'size' => 30, 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .btn' => 'border-radius: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'btn_padding', [
            'label'      => esc_html__( 'Button Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Hero Image
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_image', [
            'label' => esc_html__( 'Hero Image Styling', 'elementforge' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ] );

        $this->add_control( 'hero_image_vertical_align', [
            'label'     => esc_html__( 'Vertical Alignment', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'flex-start' => [
                    'title' => esc_html__( 'Top', 'elementforge' ),
                    'icon'  => 'eicon-v-align-top',
                ],
                'center'     => [
                    'title' => esc_html__( 'Center', 'elementforge' ),
                    'icon'  => 'eicon-v-align-middle',
                ],
                'flex-end'   => [
                    'title' => esc_html__( 'Bottom', 'elementforge' ),
                    'icon'  => 'eicon-v-align-bottom',
                ],
            ],
            'default'   => 'center',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual' => 'align-self: {{VALUE}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_image_offset_x', [
            'label'      => esc_html__( 'Horizontal Offset', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'vw' ],
            'range'      => [
                'px' => [ 'min' => -200, 'max' => 200 ],
                '%'  => [ 'min' => -50,  'max' => 50 ],
            ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual' => '--ef-hero-image-offset-x: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_image_offset_y', [
            'label'      => esc_html__( 'Vertical Offset', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'vh' ],
            'range'      => [
                'px' => [ 'min' => -200, 'max' => 200 ],
                '%'  => [ 'min' => -50,  'max' => 50 ],
            ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual' => '--ef-hero-image-offset-y: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_image_max_width', [
            'label'      => esc_html__( 'Image Max Width', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%' ],
            'range'      => [
                'px' => [ 'min' => 100, 'max' => 1000 ],
                '%'  => [ 'min' => 20,  'max' => 100 ],
            ],
            'default'    => [ 'size' => 100, 'unit' => '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_image_height', [
            'label'      => esc_html__( 'Image Height', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', 'vh', '%' ],
            'range'      => [
                'px' => [ 'min' => 100, 'max' => 1000 ],
                'vh' => [ 'min' => 10,  'max' => 100 ],
            ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image' => 'height: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'hero_image_padding', [
            'label'      => esc_html__( 'Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'hero_image_border',
                'label'    => esc_html__( 'Border', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image',
            ]
        );

        $this->add_responsive_control( 'hero_image_border_radius', [
            'label'      => esc_html__( 'Border Radius', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'hero_image_box_shadow',
                'label'    => esc_html__( 'Box Shadow', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .hero-visual img.hero-image',
            ]
        );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Badge
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_badge', [
            'label'     => esc_html__( 'Badge Styling', 'elementforge' ),
            'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_badge' => 'yes' ],
        ] );

        $this->add_responsive_control( 'badge_size', [
            'label'      => esc_html__( 'Badge Size', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [ 'px' => [ 'min' => 60, 'max' => 300 ] ],
            'default'    => [ 'size' => 140, 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .badge-bpa' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'badge_padding', [
            'label'      => esc_html__( 'Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .badge-bpa' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'badge_border',
                'label'    => esc_html__( 'Border', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .badge-bpa',
            ]
        );

        $this->add_responsive_control( 'badge_border_radius', [
            'label'      => esc_html__( 'Border Radius', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .badge-bpa' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'badge_box_shadow',
                'label'    => esc_html__( 'Box Shadow', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .badge-bpa',
            ]
        );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Features Band
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_features', [
            'label'     => esc_html__( 'Features Band Styling', 'elementforge' ),
            'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_features' => 'yes' ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'features_background',
                'label'    => esc_html__( 'Background', 'elementforge' ),
                'types'    => [ 'classic', 'gradient', 'video', 'slideshow' ],
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .features-band',
            ]
        );

        $this->add_control( 'hr_features_overlay', [
            'label' => esc_html__( 'Background Overlay', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name'     => 'features_background_overlay',
                'label'    => esc_html__( 'Background Overlay', 'elementforge' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .ef-features-band-overlay',
            ]
        );

        $this->add_control( 'features_overlay_opacity', [
            'label'     => esc_html__( 'Overlay Opacity', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 0, 'max' => 1, 'step' => 0.05 ],
            ],
            'default'   => [ 'size' => 0.5 ],
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-features-band-overlay' => 'opacity: {{SIZE}};',
            ],
        ] );

        $this->add_responsive_control( 'features_padding', [
            'label'      => esc_html__( 'Band Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .features-band' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'features_grid_gap', [
            'label'     => esc_html__( 'Columns Gap', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 10, 'max' => 100 ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .features-inner' => 'gap: {{SIZE}}{{UNIT}};',
            ],
        ] );

        // Texts styles inside Features
        $this->add_control( 'features_text_style_label', [
            'label' => esc_html__( 'Feature Content Styling', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'features_title_color', [
            'label'     => esc_html__( 'Title Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature h3' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'features_title_typography',
                'label'    => esc_html__( 'Title Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .feature h3',
            ]
        );

        $this->add_control( 'features_desc_color', [
            'label'     => esc_html__( 'Description Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#c7d4e6',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature p' => 'color: {{VALUE}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'features_desc_typography',
                'label'    => esc_html__( 'Description Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .feature p',
            ]
        );

        $this->add_control( 'feature_title_spacing', [
            'label'     => esc_html__( 'Space Below Title', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 0, 'max' => 30 ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ] );

        $this->add_control( 'feature_icon_spacing', [
            'label'     => esc_html__( 'Space Between Icon & Text', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 0, 'max' => 50 ],
            ],
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature' => 'gap: {{SIZE}}{{UNIT}};',
            ],
        ] );

        // Icon custom style settings
        $this->add_control( 'features_icon_style_label', [
            'label' => esc_html__( 'Feature Icon Styling', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
        ] );

        $this->add_control( 'features_icon_bg_color', [
            'label'     => esc_html__( 'Icon Background', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => 'rgba(255, 255, 255, 0.08)',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap' => 'background-color: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'features_icon_color', [
            'label'     => esc_html__( 'Icon Colour', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#f7a823',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap' => 'color: {{VALUE}} !important;',
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap i' => 'color: {{VALUE}} !important;',
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap svg' => 'fill: {{VALUE}} !important; color: {{VALUE}} !important;',
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap svg path' => 'fill: {{VALUE}} !important;',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'features_icon_border',
                'label'    => esc_html__( 'Icon Border', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap',
            ]
        );

        $this->add_responsive_control( 'features_icon_border_radius', [
            'label'      => esc_html__( 'Icon Border Radius', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_responsive_control( 'features_icon_padding', [
            'label'      => esc_html__( 'Icon Padding', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ] );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'features_icon_box_shadow',
                'label'    => esc_html__( 'Icon Box Shadow', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-hero-banner .feature-icon-wrap',
            ]
        );

        $this->add_control( 'hr_style_shape_divider', [
            'label' => esc_html__( 'Shape Divider Styling', 'elementforge' ),
            'type'  => \Elementor\Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_control( 'shape_divider_color', [
            'label'     => esc_html__( 'Color', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => '#0e2c52',
            'selectors' => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider' => '--ef-shape-divider-color: {{VALUE}};',
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider svg path' => 'fill: {{VALUE}};',
            ],
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_responsive_control( 'shape_divider_height', [
            'label'      => esc_html__( 'Height', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px' ],
            'range'      => [
                'px' => [ 'min' => 10, 'max' => 300, 'step' => 1 ],
            ],
            'default'    => [ 'size' => 80, 'unit' => 'px' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider svg' => 'height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_responsive_control( 'shape_divider_width', [
            'label'      => esc_html__( 'Width', 'elementforge' ),
            'type'       => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ '%' ],
            'range'      => [
                '%' => [ 'min' => 100, 'max' => 300, 'step' => 1 ],
            ],
            'default'    => [ 'size' => 100, 'unit' => '%' ],
            'selectors'  => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider svg' => 'width: calc({{SIZE}}% + 1.3px);',
            ],
            'description' => esc_html__( 'Stretch the shape wider than its container for creative effects.', 'elementforge' ),
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_control( 'shape_divider_flip', [
            'label'        => esc_html__( 'Flip', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => '',
            'selectors'    => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider svg' => 'transform: rotateY(180deg);',
            ],
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_control( 'shape_divider_invert', [
            'label'        => esc_html__( 'Invert', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => '',
            'description'  => esc_html__( 'Flips the shape vertically.', 'elementforge' ),
            'selectors'    => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider' => 'transform: rotateX(180deg);',
            ],
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->add_control( 'shape_divider_front', [
            'label'        => esc_html__( 'Bring to Front', 'elementforge' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Yes', 'elementforge' ),
            'label_off'    => esc_html__( 'No', 'elementforge' ),
            'return_value' => 'yes',
            'default'      => '',
            'selectors'    => [
                '{{WRAPPER}} .ef-element-hero-banner .ef-shape-divider' => 'z-index: 10;',
            ],
            'condition' => [
                'show_shape_divider' => 'yes',
            ],
        ] );

        $this->end_controls_section();

        /* ═══════════════════════════════════════════
         *  STYLE TAB — Particle Background
         * ═══════════════════════════════════════════ */

        $this->start_controls_section( 'section_style_particles', [
            'label'     => esc_html__( 'Particle Background Options', 'elementforge' ),
            'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
            'condition' => [ 'show_particles' => 'yes' ],
        ] );

        $this->add_control( 'particle_effect', [
            'label'   => esc_html__( 'Particle Effect', 'elementforge' ),
            'type'    => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'bubbles' => esc_html__( 'Floating Bubbles', 'elementforge' ),
            ],
            'default' => 'bubbles',
        ] );

        $this->add_control( 'particle_color', [
            'label'     => esc_html__( 'Particle Color', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::COLOR,
            'default'   => 'rgba(255, 255, 255, 0.45)',
            'selectors' => [
                '{{WRAPPER}} .ef-particle-wrap' => '--ef-particle-color: {{VALUE}};',
            ],
        ] );

        $this->add_control( 'particle_speed', [
            'label'     => esc_html__( 'Animation Speed Duration', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 2, 'max' => 25, 'step' => 1 ]
            ],
            'default'   => [ 'size' => 8 ],
            'selectors' => [
                '{{WRAPPER}} .ef-particle-wrap' => '--ef-particle-speed: {{SIZE}}s;',
            ],
            'description' => esc_html__( 'Speed mapped in animation cycle seconds (smaller duration = faster movement).', 'elementforge' ),
        ] );

        $this->add_control( 'particle_size', [
            'label'     => esc_html__( 'Base Particle Size scale', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 10, 'max' => 180, 'step' => 5 ]
            ],
            'default'   => [ 'size' => 50 ],
            'selectors' => [
                '{{WRAPPER}} .ef-particle-wrap' => '--ef-particle-size-base: {{SIZE}}px;',
            ],
        ] );

        $this->add_control( 'particle_count', [
            'label'     => esc_html__( 'Particle Count', 'elementforge' ),
            'type'      => \Elementor\Controls_Manager::SLIDER,
            'range'     => [
                'px' => [ 'min' => 1, 'max' => 20, 'step' => 1 ]
            ],
            'default'   => [ 'size' => 7 ],
            'render_type' => 'template',
        ] );

        $this->end_controls_section();
    }


    /* ═══════════════════════════════════════════
     *  RENDER
     * ═══════════════════════════════════════════ */

    protected function render() {
        $s = $this->get_settings_for_display();

        // Icon position classes
        $icon_position = ! empty( $s['features_icon_position'] ) ? $s['features_icon_position'] : 'side';
        $hero_classes  = 'ef-element-hero-banner ef-features-icon-' . esc_attr( $icon_position );
        ?>
        <section class="<?php echo esc_attr( $hero_classes ); ?>">

            <!-- Background Overlay -->
            <div class="ef-element-hero-banner-overlay"></div>

            <!-- Dynamic Background elements: Video & Slideshow -->
            <?php
            // Video Background
            if ( 'video' === $s['hero_background_background'] && ! empty( $s['hero_background_video_link'] ) ) {
                $video_url = $s['hero_background_video_link'];
                if ( preg_match( '/(youtube\.com|youtu\.be)/', $video_url ) ) {
                    $video_id = '';
                    if ( preg_match( '/embed\/([^&\?]+)/', $video_url, $matches ) ) {
                        $video_id = $matches[1];
                    } elseif ( preg_match( '/v=([^&\?]+)/', $video_url, $matches ) ) {
                        $video_id = $matches[1];
                    } elseif ( preg_match( '/youtu\.be\/([^&\?]+)/', $video_url, $matches ) ) {
                        $video_id = $matches[1];
                    }
                    if ( ! empty( $video_id ) ) {
                        ?>
                        <div class="ef-hero-bg-video-wrap">
                            <iframe src="https://www.youtube.com/embed/<?php echo esc_attr( $video_id ); ?>?autoplay=1&mute=1&loop=1&playlist=<?php echo esc_attr( $video_id ); ?>&controls=0&showinfo=0&rel=0&enablejsapi=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        </div>
                        <?php
                    }
                } elseif ( preg_match( '/vimeo\.com/', $video_url ) ) {
                    $video_id = '';
                    if ( preg_match( '/vimeo\.com\/(\d+)/', $video_url, $matches ) ) {
                        $video_id = $matches[1];
                    }
                    if ( ! empty( $video_id ) ) {
                        ?>
                        <div class="ef-hero-bg-video-wrap">
                            <iframe src="https://player.vimeo.com/video/<?php echo esc_attr( $video_id ); ?>?autoplay=1&loop=1&muted=1&background=1" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="ef-hero-bg-video-wrap">
                        <video autoplay loop muted playsinline>
                            <source src="<?php echo esc_url( $video_url ); ?>" type="video/mp4">
                        </video>
                    </div>
                    <?php
                }
            }

            // Slideshow Background
            if ( 'slideshow' === $s['hero_background_background'] && ! empty( $s['hero_background_slideshow_gallery'] ) ) {
                $unique_id = 'ef-slideshow-' . esc_attr( $this->get_id() );
                ?>
                <div class="ef-hero-bg-slideshow-wrap" id="<?php echo esc_attr( $unique_id ); ?>">
                    <?php foreach ( $s['hero_background_slideshow_gallery'] as $index => $image ) : 
                        $active_class = ( 0 === $index ) ? ' active' : '';
                        ?>
                        <div class="ef-hero-bg-slide<?php echo esc_attr( $active_class ); ?>" style="background-image: url(<?php echo esc_url( $image['url'] ); ?>);"></div>
                    <?php endforeach; ?>
                </div>
                <script>
                (function() {
                    var initSlideshow = function() {
                        var wrap = document.getElementById('<?php echo esc_js( $unique_id ); ?>');
                        if ( wrap ) {
                            var slides = wrap.querySelectorAll('.ef-hero-bg-slide');
                            if (slides.length > 1) {
                                var current = 0;
                                setInterval(function() {
                                    slides[current].classList.remove('active');
                                    current = (current + 1) % slides.length;
                                    slides[current].classList.add('active');
                                }, 5000);
                            }
                        }
                    };
                    if (document.readyState === 'loading') {
                        document.addEventListener('DOMContentLoaded', initSlideshow);
                    } else {
                        initSlideshow();
                    }
                })();
                </script>
                <?php
            }
            ?>

            <!-- Particle decorations -->
            <?php if ( 'yes' === $s['show_particles'] ) : 
                $count = ! empty( $s['particle_count']['size'] ) ? intval( $s['particle_count']['size'] ) : 7;
                
                // Hash-based random placement: all positions recalculate when count changes
                $widget_uid = $this->get_id();
                ?>
                <div class="ef-particle-wrap" data-effect="<?php echo esc_attr( $s['particle_effect'] ); ?>" aria-hidden="true">
                    <?php for ( $i = 1; $i <= $count; $i++ ) {
                        $hash  = crc32( $widget_uid . '-' . $count . '-' . $i );
                        $left  = abs( $hash % 9000 ) / 100;
                        $top   = abs( ( $hash >> 8 ) % 8500 ) / 100;
                        $delay = round( abs( ( $hash >> 16 ) % 500 ) / 100, 1 );
                        $speed = round( 0.7 + abs( ( $hash >> 12 ) % 100 ) / 125, 2 );
                        $size  = round( 0.3 + abs( ( $hash >> 4 ) % 150 ) / 100, 2 );

                        $style = "left: {$left}%; top: {$top}%; animation-delay: {$delay}s; --bubble-speed-mult: {$speed}; --bubble-size-mult: {$size};";
                        echo '<span class="bubble bubble-' . $i . '" style="' . esc_attr( $style ) . '"></span>';
                    } ?>
                </div>
            <?php endif; ?>

            <div class="hero-inner">

                <!-- Text Column -->
                <div class="hero-text">

                    <?php if ( ! empty( $s['subheading'] ) && 'above' === $s['subheading_position'] ) : ?>
                        <p class="hero-sub"><?php echo wp_kses_post( $s['subheading'] ); ?></p>
                    <?php endif; ?>

                    <?php if ( ! empty( $s['heading'] ) ) : ?>
                        <h1 class="hero-heading">
                            <?php echo wp_kses_post( $s['heading'] ); ?>
                        </h1>
                    <?php endif; ?>

                    <?php if ( ! empty( $s['subheading'] ) && 'below' === $s['subheading_position'] ) : ?>
                        <p class="hero-sub"><?php echo wp_kses_post( $s['subheading'] ); ?></p>
                    <?php endif; ?>

                    <?php if ( ! empty( $s['content'] ) ) : ?>
                        <div class="hero-content"><?php echo wp_kses_post( $s['content'] ); ?></div>
                    <?php endif; ?>

                    <?php if ( ! empty( $s['checklist_items'] ) ) : ?>
                    <ul class="hero-checklist">
                        <?php foreach ( $s['checklist_items'] as $item ) : ?>
                            <?php if ( ! empty( $item['checklist_text'] ) ) : ?>
                            <li>
                                <span class="check-icon">
                                    <?php \Elementor\Icons_Manager::render_icon( $s['checklist_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </span>
                                <?php echo esc_html( $item['checklist_text'] ); ?>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>

                    <div class="hero-ctas">
                        <!-- Primary CTA Button -->
                        <?php if ( 'yes' === $s['show_btn_primary'] && ! empty( $s['btn_primary_text'] ) ) :
                            $this->add_render_attribute( 'btn_primary', 'class', 'btn btn-primary' );
                            if ( ! empty( $s['btn_primary_link']['url'] ) ) {
                                $this->add_link_attributes( 'btn_primary', $s['btn_primary_link'] );
                            }
                        ?>
                        <a <?php $this->print_render_attribute_string( 'btn_primary' ); ?>>
                            <?php echo esc_html( $s['btn_primary_text'] ); ?>
                            <?php \Elementor\Icons_Manager::render_icon( $s['btn_primary_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                        <?php endif; ?>

                        <!-- Secondary CTA Button -->
                        <?php if ( 'yes' === $s['show_btn_secondary'] && ! empty( $s['btn_secondary_text'] ) ) :
                            $this->add_render_attribute( 'btn_secondary', 'class', 'btn btn-outline' );
                            if ( ! empty( $s['btn_secondary_link']['url'] ) ) {
                                $this->add_link_attributes( 'btn_secondary', $s['btn_secondary_link'] );
                            }
                        ?>
                        <a <?php $this->print_render_attribute_string( 'btn_secondary' ); ?>>
                            <?php echo esc_html( $s['btn_secondary_text'] ); ?>
                            <?php \Elementor\Icons_Manager::render_icon( $s['btn_secondary_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                        <?php endif; ?>
                    </div>

                </div>

                <!-- Visual Column -->
                <div class="hero-visual">
                    <?php if ( ! empty( $s['hero_image']['url'] ) ) : ?>
                        <img src="<?php echo esc_url( $s['hero_image']['url'] ); ?>"
                             alt="<?php echo esc_attr( strip_tags( $s['heading'] ) ); ?>"
                             class="hero-image" />
                    <?php endif; ?>

                    <?php if ( 'yes' === $s['show_badge'] && ! empty( $s['badge_image']['url'] ) ) : ?>
                    <div class="badge-bpa">
                        <img src="<?php echo esc_url( $s['badge_image']['url'] ); ?>"
                             alt="<?php echo esc_attr__( 'Badge', 'elementforge' ); ?>" />
                    </div>
                    <?php endif; ?>
                </div>

            </div>

            <?php if ( 'yes' === $s['show_features'] ) : ?>
            <!-- Features Band -->
            <div class="features-band">
                <!-- Features Band Overlay -->
                <div class="ef-features-band-overlay"></div>

                <?php
                // Features Band — Video Background
                $fb_bg_type = ! empty( $s['features_background_background'] ) ? $s['features_background_background'] : '';
                if ( 'video' === $fb_bg_type && ! empty( $s['features_background_video_link'] ) ) {
                    $fb_vid = $s['features_background_video_link'];
                    if ( preg_match( '/(youtube\.com|youtu\.be)/', $fb_vid ) ) {
                        $fb_vid_id = '';
                        if ( preg_match( '/embed\/([^&\?]+)/', $fb_vid, $m ) ) { $fb_vid_id = $m[1]; }
                        elseif ( preg_match( '/v=([^&\?]+)/', $fb_vid, $m ) ) { $fb_vid_id = $m[1]; }
                        elseif ( preg_match( '/youtu\.be\/([^&\?]+)/', $fb_vid, $m ) ) { $fb_vid_id = $m[1]; }
                        if ( $fb_vid_id ) { ?>
                            <div class="ef-hero-bg-video-wrap">
                                <iframe src="https://www.youtube.com/embed/<?php echo esc_attr( $fb_vid_id ); ?>?autoplay=1&mute=1&loop=1&playlist=<?php echo esc_attr( $fb_vid_id ); ?>&controls=0&showinfo=0&rel=0&enablejsapi=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                            </div>
                        <?php }
                    } elseif ( preg_match( '/vimeo\.com/', $fb_vid ) ) {
                        $fb_vim_id = '';
                        if ( preg_match( '/vimeo\.com\/(\d+)/', $fb_vid, $m ) ) { $fb_vim_id = $m[1]; }
                        if ( $fb_vim_id ) { ?>
                            <div class="ef-hero-bg-video-wrap">
                                <iframe src="https://player.vimeo.com/video/<?php echo esc_attr( $fb_vim_id ); ?>?autoplay=1&loop=1&muted=1&background=1" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                            </div>
                        <?php }
                    } else { ?>
                        <div class="ef-hero-bg-video-wrap">
                            <video autoplay loop muted playsinline>
                                <source src="<?php echo esc_url( $fb_vid ); ?>" type="video/mp4">
                            </video>
                        </div>
                    <?php }
                }

                // Features Band — Slideshow Background
                if ( 'slideshow' === $fb_bg_type && ! empty( $s['features_background_slideshow_gallery'] ) ) {
                    $fb_ss_id = 'ef-fb-slideshow-' . esc_attr( $this->get_id() );
                    ?>
                    <div class="ef-hero-bg-slideshow-wrap" id="<?php echo esc_attr( $fb_ss_id ); ?>">
                        <?php foreach ( $s['features_background_slideshow_gallery'] as $si => $simg ) :
                            $ac = ( 0 === $si ) ? ' active' : '';
                        ?>
                            <div class="ef-hero-bg-slide<?php echo esc_attr( $ac ); ?>" style="background-image: url(<?php echo esc_url( $simg['url'] ); ?>);"></div>
                        <?php endforeach; ?>
                    </div>
                    <script>
                    (function() {
                        var init = function() {
                            var w = document.getElementById('<?php echo esc_js( $fb_ss_id ); ?>');
                            if (w) {
                                var sl = w.querySelectorAll('.ef-hero-bg-slide');
                                if (sl.length > 1) {
                                    var c = 0;
                                    setInterval(function() { sl[c].classList.remove('active'); c = (c + 1) % sl.length; sl[c].classList.add('active'); }, 5000);
                                }
                            }
                        };
                        if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
                    })();
                    </script>
                <?php } ?>

                <?php if ( 'yes' === $s['show_shape_divider'] ) :
                    $shape_type = ! empty( $s['shape_divider_type'] ) ? $s['shape_divider_type'] : 'wave';
                ?>
                <!-- Shape Divider -->
                <div class="ef-shape-divider" data-shape="<?php echo esc_attr( $shape_type ); ?>" aria-hidden="true">
                    <?php echo $this->get_shape_divider_svg( $shape_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                </div>
                <?php endif; ?>

                <div class="features-inner">
                    <?php foreach ( $s['features'] as $index => $feature ) : ?>
                    <div class="feature">
                        <div class="feature-icon-wrap">
                            <?php \Elementor\Icons_Manager::render_icon( $feature['feature_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </div>
                        <div class="feature-text-wrap">
                            <?php if ( ! empty( $feature['feature_title'] ) ) : ?>
                                <h3><?php echo esc_html( $feature['feature_title'] ); ?></h3>
                            <?php endif; ?>
                            <?php if ( ! empty( $feature['feature_desc'] ) ) : ?>
                                <p><?php echo esc_html( $feature['feature_desc'] ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </section>
        <?php
    }

    /**
     * Get shape divider SVG path based on selected type.
     *
     * @param string $shape_type
     * @return string
     */
    protected function get_shape_divider_svg( $shape_type ) {
        $svgs = [
            'wave' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 80" preserveAspectRatio="none"><path d="M0,55 Q720,0 1440,55 L1440,80 L0,80 Z" /></svg>',
            'wave-multi' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 C150,0 350,100 500,50 C650,0 850,100 1000,0 L1000,100 L0,100 Z" /></svg>',
            'triangle' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 L500,0 L1000,100 Z" /></svg>',
            'tilt' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 L1000,0 L1000,100 Z" /></svg>',
            'arrow' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 L0,50 L500,0 L1000,50 L1000,100 Z" /></svg>',
            'curve' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 C250,0 750,0 1000,100 Z" /></svg>',
            'mountains' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 L200,40 L400,80 L650,20 L800,70 L1000,10 L1000,100 Z" /></svg>',
            'zigzag' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 L0,20 L100,80 L200,20 L300,80 L400,20 L500,80 L600,20 L700,80 L800,20 L900,80 L1000,20 L1000,100 Z" /></svg>',
            'clouds' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 C50,60 100,60 150,80 C200,50 300,50 380,85 C450,40 550,40 620,80 C700,30 800,30 880,75 C930,60 970,60 1000,100 Z" /></svg>',
            'drops' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M0,100 Q100,50 200,100 Q300,20 400,100 Q500,40 600,100 Q700,10 800,100 Q900,60 1000,100 Z" /></svg>',
        ];

        return isset( $svgs[ $shape_type ] ) ? $svgs[ $shape_type ] : '';
    }
}

