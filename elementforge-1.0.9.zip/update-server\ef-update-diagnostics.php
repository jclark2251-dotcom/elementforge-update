<?php
/**
 * ElementForge GitHub Update Diagnostics
 * 
 * Paste this snippet at the bottom of your theme's functions.php file on the development site.
 * Refresh the admin dashboard. Let's see what is stored in the database.
 */
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $cache_key = 'elementforge_remote_update_info';
    $cached = get_transient( $cache_key );
    $wp_transient = get_site_transient( 'update_plugins' );
    
    echo '<div class="notice notice-warning" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff; margin-top: 20px;">';
    echo '<h3>ElementForge GitHub Update Diagnostics</h3>';
    
    // Show current versions
    echo '<p><strong>1. Installed Version:</strong> ' . (defined('ELEMENTFORGE_VERSION') ? esc_html(ELEMENTFORGE_VERSION) : 'Not defined') . '</p>';
    
    // Show cache status
    echo '<p><strong>2. ElementForge Update Cache:</strong><br />';
    if ( $cached === false ) {
        echo 'Cache is EMPTY (false)<br />';
    } else {
        echo 'Cache is POPULATED:<br />';
        echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 120px; overflow: auto;">' . esc_html( print_r( $cached, true ) ) . '</pre>';
    }
    echo '</p>';

    // Show WordPress update transient status
    echo '<p><strong>3. WordPress core transient check:</strong><br />';
    if ( !$wp_transient ) {
        echo 'update_plugins transient is EMPTY<br />';
    } else {
        $ef_response = isset( $wp_transient->response['elementforge/elementforge.php'] ) ? $wp_transient->response['elementforge/elementforge.php'] : null;
        $ef_no_update = isset( $wp_transient->no_update['elementforge/elementforge.php'] ) ? $wp_transient->no_update['elementforge/elementforge.php'] : null;
        
        if ( $ef_response ) {
            echo '<span style="color: green;">✅ Update is registered in WordPress! (Target Version: ' . esc_html( $ef_response->new_version ) . ')</span><br />';
            echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 120px; overflow: auto;">' . esc_html( print_r( $ef_response, true ) ) . '</pre>';
        } elseif ( $ef_no_update ) {
            echo '<span style="color: red;">❌ WordPress thinks there is NO UPDATE.</span> (WordPress registered version: ' . esc_html( $ef_no_update->new_version ) . ')<br />';
        } else {
            echo '❌ ElementForge is NOT registered in the WordPress updates list at all.<br />';
        }
    }
    echo '</p>';

    // Action button
    echo '<p><a href="?force_clear_ef=1" class="button button-secondary">Force Clear Cache & Re-check</a></p>';
    
    if ( isset( $_GET['force_clear_ef'] ) ) {
        delete_transient( $cache_key );
        delete_site_transient( 'update_plugins' );
        wp_safe_redirect( remove_query_arg( 'force_clear_ef' ) );
        exit;
    }
    
    echo '</div>';
});
