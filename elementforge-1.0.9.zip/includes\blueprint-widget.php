<?php
/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           ELEMENTFORGE — WIDGET BLUEPRINT TEMPLATE          ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║  INSTRUCTIONS:                                              ║
 * ║  1. Copy this entire file into:                             ║
 * ║     /elements/your-element-id/widget.php                    ║
 * ║  2. Find & Replace the following placeholders:              ║
 * ║     • ELEMENT_ID      → your-element-slug  (e.g. "hero")   ║
 * ║     • ELEMENT_CLASS    → Your_Class_Name    (e.g. "Hero")   ║
 * ║     • ELEMENT_TITLE    → Human-Readable     (e.g. "Hero")   ║
 * ║     • ELEMENT_ICON     → Elementor icon     (e.g. "eicon-") ║
 * ║  3. Uncomment only the control sections you need.           ║
 * ║  4. Build your HTML in the render() method at the bottom.   ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

namespace ElementForge\Elements;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ELEMENT_CLASS extends \Elementor\Widget_Base {

    /* ─────────────────────────────────────────────
     *  IDENTITY
     * ───────────────────────────────────────────── */

    public function get_name() {
        return 'ELEMENT_ID';
    }

    public function get_title() {
        return esc_html__( 'ELEMENT_TITLE', 'elementforge' );
    }

    public function get_icon() {
        return 'ELEMENT_ICON';
    }

    public function get_categories() {
        return [ 'forge-elements' ];
    }

    /**
     * Optional: Load element-specific CSS on the frontend.
     * Place your stylesheet in /elements/ELEMENT_ID/style.css
     */
    public function get_style_depends() {
        $handle = 'ef-ELEMENT_ID-style';
        // Register on-demand so the file is only loaded when the widget is on the page.
        wp_register_style(
            $handle,
            ELEMENTFORGE_URL . 'elements/ELEMENT_ID/style.css',
            [],
            ELEMENTFORGE_VERSION
        );
        return [ $handle ];
    }

    /* ═════════════════════════════════════════════
     *  CONTROLS — Uncomment sections as needed
     * ═════════════════════════════════════════════ */

    protected function register_controls() {

        /* ┌──────────────────────────────────────┐
         * │         CONTENT TAB                  │
         * └──────────────────────────────────────┘ */

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'Content', 'elementforge' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // ── Text Control ──────────────────────────
        $this->add_control(
            'ef_text',
            [
                'label'       => esc_html__( 'Text', 'elementforge' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Hello World', 'elementforge' ),
                'placeholder' => esc_html__( 'Enter your text', 'elementforge' ),
                'label_block' => true,
            ]
        );

        // ── Textarea / Rich Text Control ──────────
        // Uncomment for multi-line or WYSIWYG content.
        /*
        $this->add_control(
            'ef_description',
            [
                'label'   => esc_html__( 'Description', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::WYSIWYG,
                'default' => esc_html__( 'Your description here.', 'elementforge' ),
            ]
        );
        */

        // ── Image Control ─────────────────────────
        /*
        $this->add_control(
            'ef_image',
            [
                'label'   => esc_html__( 'Choose Image', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        */

        // ── URL / Link Control ────────────────────
        /*
        $this->add_control(
            'ef_link',
            [
                'label'       => esc_html__( 'Link', 'elementforge' ),
                'type'        => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__( 'https://your-link.com', 'elementforge' ),
                'default'     => [
                    'url'         => '#',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );
        */

        // ── Select / Dropdown Control ─────────────
        /*
        $this->add_control(
            'ef_layout',
            [
                'label'   => esc_html__( 'Layout', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__( 'Default', 'elementforge' ),
                    'stacked' => esc_html__( 'Stacked', 'elementforge' ),
                    'inline'  => esc_html__( 'Inline', 'elementforge' ),
                ],
            ]
        );
        */

        // ── Switcher / Toggle Control ─────────────
        /*
        $this->add_control(
            'ef_show_icon',
            [
                'label'        => esc_html__( 'Show Icon', 'elementforge' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Yes', 'elementforge' ),
                'label_off'    => esc_html__( 'No', 'elementforge' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
        */

        // ── Number Control ────────────────────────
        /*
        $this->add_control(
            'ef_columns',
            [
                'label'   => esc_html__( 'Columns', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 6,
                'step'    => 1,
                'default' => 3,
            ]
        );
        */

        $this->end_controls_section();


        /* ┌──────────────────────────────────────┐
         * │          STYLE TAB                   │
         * └──────────────────────────────────────┘ */

        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__( 'Style', 'elementforge' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        // ── Text Color ────────────────────────────
        /*
        $this->add_control(
            'ef_text_color',
            [
                'label'     => esc_html__( 'Text Color', 'elementforge' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#333333',
                'selectors' => [
                    '{{WRAPPER}} .ef-element-ELEMENT_ID' => 'color: {{VALUE}};',
                ],
            ]
        );
        */

        // ── Background Color ──────────────────────
        /*
        $this->add_control(
            'ef_bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'elementforge' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ef-element-ELEMENT_ID' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        */

        // ── Padding ───────────────────────────────
        /*
        $this->add_responsive_control(
            'ef_padding',
            [
                'label'      => esc_html__( 'Padding', 'elementforge' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .ef-element-ELEMENT_ID' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        */

        // ── Margin ────────────────────────────────
        /*
        $this->add_responsive_control(
            'ef_margin',
            [
                'label'      => esc_html__( 'Margin', 'elementforge' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .ef-element-ELEMENT_ID' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        */

        // ── Border Radius ─────────────────────────
        /*
        $this->add_responsive_control(
            'ef_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'elementforge' ),
                'type'       => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors'  => [
                    '{{WRAPPER}} .ef-element-ELEMENT_ID' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        */

        // ── Typography (requires Group_Control) ───
        /*
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'     => 'ef_typography',
                'label'    => esc_html__( 'Typography', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-ELEMENT_ID',
            ]
        );
        */

        // ── Box Shadow ────────────────────────────
        /*
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'ef_box_shadow',
                'label'    => esc_html__( 'Box Shadow', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-ELEMENT_ID',
            ]
        );
        */

        // ── Border ────────────────────────────────
        /*
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name'     => 'ef_border',
                'label'    => esc_html__( 'Border', 'elementforge' ),
                'selector' => '{{WRAPPER}} .ef-element-ELEMENT_ID',
            ]
        );
        */

        $this->end_controls_section();


        /* ┌──────────────────────────────────────┐
         * │       ANIMATION TAB (Bonus)          │
         * └──────────────────────────────────────┘ */

        /*
        $this->start_controls_section(
            'section_animation',
            [
                'label' => esc_html__( 'Animation', 'elementforge' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'ef_entrance_animation',
            [
                'label'   => esc_html__( 'Entrance Animation', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::ANIMATION,
                'default' => '',
                'prefix_class' => 'animated ',  // Elementor ships Animate.css
            ]
        );

        $this->add_control(
            'ef_animation_duration',
            [
                'label'   => esc_html__( 'Animation Duration', 'elementforge' ),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    'slow'   => esc_html__( 'Slow', 'elementforge' ),
                    ''       => esc_html__( 'Normal', 'elementforge' ),
                    'fast'   => esc_html__( 'Fast', 'elementforge' ),
                ],
                'prefix_class' => 'animated-',
                'condition'    => [
                    'ef_entrance_animation!' => '',
                ],
            ]
        );

        $this->end_controls_section();
        */
    }


    /* ═════════════════════════════════════════════
     *  RENDER — Build your HTML here
     * ═════════════════════════════════════════════ */

    protected function render() {
        $settings = $this->get_settings_for_display();

        // ── Scoped wrapper class ──────────────────
        // Every Forge Element uses .ef-element-{id} as its root.
        // All your CSS selectors should descend from this class.
        ?>
        <div class="ef-element-ELEMENT_ID">

            <?php
            // ── Text output ──
            if ( ! empty( $settings['ef_text'] ) ) : ?>
                <h2 class="ef-element-ELEMENT_ID__title">
                    <?php echo esc_html( $settings['ef_text'] ); ?>
                </h2>
            <?php endif; ?>

            <?php
            // ── Image output (uncomment when using ef_image) ──
            /*
            if ( ! empty( $settings['ef_image']['url'] ) ) :
                echo \Elementor\Group_Control_Image_Size::get_attachment_image_html( $settings, 'full', 'ef_image' );
            endif;
            */
            ?>

            <?php
            // ── Link output (uncomment when using ef_link) ──
            /*
            if ( ! empty( $settings['ef_link']['url'] ) ) :
                $this->add_link_attributes( 'ef_link', $settings['ef_link'] );
                ?>
                <a <?php $this->print_render_attribute_string( 'ef_link' ); ?> class="ef-element-ELEMENT_ID__link">
                    <?php echo esc_html__( 'Learn More', 'elementforge' ); ?>
                </a>
                <?php
            endif;
            */
            ?>

            <?php
            // ── Description output (uncomment when using ef_description) ──
            /*
            if ( ! empty( $settings['ef_description'] ) ) : ?>
                <div class="ef-element-ELEMENT_ID__desc">
                    <?php echo wp_kses_post( $settings['ef_description'] ); ?>
                </div>
            <?php endif;
            */
            ?>

        </div>
        <?php
    }
}
