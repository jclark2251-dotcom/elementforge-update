<?php
/**
 * ElementForge Update Server - info.php
 *
 * A standalone PHP endpoint to serve plugin update metadata.
 * Upload this file to your server (outside the WordPress plugin directory),
 * e.g. at: https://plugins.sitestaging.com.au/elementforge-api/info.php
 *
 * Then update ELEMENTFORGE_UPDATE_URL in elementforge.php to point here.
 */

// Prevent direct WordPress bootstrap interference.
// This file is meant to be called directly by HTTP.
header( 'Content-Type: application/json; charset=utf-8' );
header( 'Cache-Control: no-cache, must-revalidate' );

$info = [
    'name'         => 'ElementForge',
    'slug'         => 'elementforge',
    'version'      => '1.0.5',
    'download_url' => 'https://plugins.sitestaging.com.au/elementforge/elementforge-1.0.5.zip',
    'author'       => 'ElementForge Team',
    'requires'     => '6.0',
    'tested'       => '6.5',
    'sections'     => [
        'description' => 'A lightweight, modular Elementor extension companion.',
        'changelog'   => '<h4>1.0.5</h4><ul><li>Fixed update detection mechanism. Removed bad-response caching.</li></ul><h4>1.0.4</h4><ul><li>Added self-hosted update system.</li></ul><h4>1.0.3</h4><ul><li>Added Subheading position placement settings (above/below).</li><li>Added Hero Image layout and offset controls.</li></ul>',
    ],
];

echo json_encode( $info, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
