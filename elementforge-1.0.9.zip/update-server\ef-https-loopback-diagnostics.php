<?php
/**
 * ElementForge HTTPS Loopback Diagnostics
 * 
 * Paste this snippet at the bottom of your theme's functions.php file on the development site.
 * Let's test if connecting to 127.0.0.1 or the public IP via HTTPS (Port 443) works.
 */
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    echo '<div class="notice notice-warning" style="padding: 15px; border-left: 4px solid #ffb900; background: #fff; margin-top: 20px;">';
    echo '<h3>ElementForge HTTPS Loopback Diagnostics</h3>';
    
    // Test 1: https://127.0.0.1/ with Host header
    echo '<p><strong>Test 1: https://127.0.0.1/ (HTTPS) with Host header:</strong><br />';
    $response1 = wp_remote_get( 'https://127.0.0.1/elementforge/info.json', array(
        'timeout'    => 10,
        'sslverify'  => false,
        'headers'    => array(
            'Host'   => 'plugins.sitestaging.com.au',
            'Accept' => 'application/json'
        )
    ) );
    
    if ( is_wp_error( $response1 ) ) {
        echo '<span style="color: red;">❌ Test 1 failed: ' . esc_html( $response1->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response1 );
        $body = wp_remote_retrieve_body( $response1 );
        echo '<span style="color: green;">✅ Test 1 Succeeded (HTTP Code ' . $code . ')</span><br />';
        if ( $code === 200 ) {
            echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 120px; overflow: auto;">' . esc_html( $body ) . '</pre>';
        }
    }
    echo '</p>';

    // Test 2: https://115.70.226.115/ with Host header
    echo '<p><strong>Test 2: https://115.70.226.115/ (HTTPS) with Host header:</strong><br />';
    $response2 = wp_remote_get( 'https://115.70.226.115/elementforge/info.json', array(
        'timeout'    => 10,
        'sslverify'  => false,
        'headers'    => array(
            'Host'   => 'plugins.sitestaging.com.au',
            'Accept' => 'application/json'
        )
    ) );
    
    if ( is_wp_error( $response2 ) ) {
        echo '<span style="color: red;">❌ Test 2 failed: ' . esc_html( $response2->get_error_message() ) . '</span>';
    } else {
        $code = wp_remote_retrieve_response_code( $response2 );
        $body = wp_remote_retrieve_body( $response2 );
        echo '<span style="color: green;">✅ Test 2 Succeeded (HTTP Code ' . $code . ')</span><br />';
        if ( $code === 200 ) {
            echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ccc; max-height: 120px; overflow: auto;">' . esc_html( $body ) . '</pre>';
        }
    }
    echo '</p>';
    
    echo '</div>';
});
