# ElementForge Automated Release Script
# Runs git push to publish updates to your GitHub repository

$ErrorActionPreference = "Stop"

# Paths
$pluginPath = "c:\Users\jarrod\Local Sites\test-site\app\public\wp-content\plugins\elementforge"
$gitPath    = "c:\Users\jarrod\Local Sites\test-site\app\public\wp-content\plugins\elementforge-update-git"
$jsonPath   = "$pluginPath\update-server\info.json"

# Check if info.json exists
if (!(Test-Path $jsonPath)) {
    Write-Error "Could not find info.json at $jsonPath"
}

# 1. Parse version from info.json
$json = Get-Content $jsonPath -Raw | ConvertFrom-Json
$version = $json.version
Write-Output "Preparing release for version: $version"

# 2. Rebuild the ZIP file directly into the Git repository
$zipName = "elementforge-$version.zip"
$zipPath = "$gitPath\$zipName"

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

Write-Output "Building ZIP archive..."
# Compress-Archive creates paths with backslashes which breaks WordPress extraction on some environments.
# We use the built-in Windows tar command instead to ensure standard forward-slash paths.
$pluginsDir = Split-Path $pluginPath
$pluginFolderName = Split-Path $pluginPath -Leaf
$origLocation = Get-Location
Set-Location $pluginsDir
tar -a -c -f $zipPath $pluginFolderName
Set-Location $origLocation
Write-Output "ZIP built at $zipPath"

# 3. Copy info.json to Git repository
Copy-Item $jsonPath "$gitPath\info.json" -Force
Write-Output "info.json copied to Git repository"

# 4. Commit and push changes
Write-Output "Running Git operations..."
Set-Location $gitPath

# Make sure we are up to date
git pull origin main

# Add and commit
git add .
$status = git status --porcelain
if ($status) {
    git commit -m "Release version $version"
    git push origin main
    Write-Output "SUCCESS: Version $version has been published to GitHub!"
} else {
    Write-Output "No changes detected. Release is already up to date."
}
