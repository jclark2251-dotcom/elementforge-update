<?php
/**
 * Plugin Name: ElementForge
 * Description: A lightweight, modular Elementor extension companion.
 * Version:     1.1.1
 * Author:      Jarrod Clark
 * License:     GPL-2.0+
 * Text Domain: elementforge
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define Constants
define( 'ELEMENTFORGE_VERSION', '1.0.9' );
define( 'ELEMENTFORGE_FILE', __FILE__ );
define( 'ELEMENTFORGE_PATH', plugin_dir_path( __FILE__ ) );
define( 'ELEMENTFORGE_URL', plugin_dir_url( __FILE__ ) );
define( 'ELEMENTFORGE_UPDATE_URL', 'https://raw.githubusercontent.com/jclark2251-dotcom/elementforge-update/main/info.json' );

// Autoload/require necessary classes
require_once ELEMENTFORGE_PATH . 'includes/class-compatibility-helper.php';
require_once ELEMENTFORGE_PATH . 'includes/class-element-loader.php';
require_once ELEMENTFORGE_PATH . 'includes/class-plugin-updater.php';

// Only load Admin logic in dashboard
if ( is_admin() ) {
    require_once ELEMENTFORGE_PATH . 'admin/class-admin-page.php';
}

// Initialize the plugin logic
add_action( 'plugins_loaded', function() {
    // Bootstrap Loader
    \ElementForge\Includes\Element_Loader::instance()->init();

    // Bootstrap Admin Screen and Updater
    if ( is_admin() ) {
        \ElementForge\Admin\Admin_Page::instance()->init();
        new \ElementForge\Includes\Plugin_Updater( ELEMENTFORGE_FILE, ELEMENTFORGE_UPDATE_URL );
    }
} );
